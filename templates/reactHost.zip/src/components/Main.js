import React from "react";
import "../styles/Main.css";
import shapeSorterConfig from "../../.shapesorterrc.json";

function Main() {
  return (
    <div>
      <h1>{shapeSorterConfig.name}</h1>
    </div>
  );
}

export default Main;
