import React from "react";
import Main from "./components/Main";
const App = () => {
  return <Main />;
};

export default App;
