import React from "react";
import "../styles/Main.css";
import * as shapeSorterConfig from "../../.shapesorterrc.json";
function Main(props) {
  return (
    <div>
      <h1>{shapeSorterConfig.name}</h1>
    </div>
  );
}

export default Main;
